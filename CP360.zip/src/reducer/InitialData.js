let initialData = {
    signin: false 
}
export default initialData;