export const colors = ['red', 'yellow', 'green', 'blue'];

export const components = [
    {"title":"React", "id": "react" },
    {"title":"Angular", "id": "angular"},
    {"title":"Vue", "id": "vue" },
    {"title":"Ember", "id": "ember"}
];