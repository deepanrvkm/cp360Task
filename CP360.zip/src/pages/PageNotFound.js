function PageNotFound() {
    return (
        <div className="pagenot-found">
            <h1>Page 404 Not Found</h1>
        </div>
    );
}

export default PageNotFound;